import Controller.MenuController;

public class main {

    public static void main(String[] args){

        MenuController menuController = new MenuController();

        menuController.menu();
    }
}
